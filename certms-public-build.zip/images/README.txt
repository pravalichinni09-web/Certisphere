CertiSphere brand logo
======================

Drop your actual PNG / JPG of the CertiSphere wordmark here as
    certisphere-logo.png

The login page tries to load that file first. If it's missing it
falls back to the SVG recreation at
    certisphere-logo.svg
and finally to a generic user-icon if both are unavailable.

So all you need to do is save your PNG with the exact filename
"certisphere-logo.png" in this folder and refresh the login page.
